#!/bin/bash
cd ios/ && bundle install && bundle exec pod install && cd ..
