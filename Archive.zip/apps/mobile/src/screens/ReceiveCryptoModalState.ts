import { FORServiceProvider } from 'wallet/src/features/fiatOnRamp/types'

export type ReceiveCryptoModalState = FORServiceProvider[]
