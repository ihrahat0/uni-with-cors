// AppsFlyer automatically routes to the correct store based on the device
export const APP_STORE_LINK = 'https://uniswapwallet.onelink.me/8q3y/97upfib8'

export const APP_FEEDBACK_LINK =
  'https://docs.google.com/forms/d/e/1FAIpQLSepzL5aMuSfRhSgw0zDw_gVmc2aeVevfrb1UbOwn6WGJ--46w/viewform'
