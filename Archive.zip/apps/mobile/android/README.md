# Known Issues

Android 14 (API level 34) features cannot be used until we upgrade to React Native 0.71.13. That means that the sdk versions cannot be upgraded to 34 until React Native is also upgraded.
https://github.com/facebook/react-native/issues/37769
