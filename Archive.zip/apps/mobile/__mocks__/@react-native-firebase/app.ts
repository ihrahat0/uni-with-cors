/* eslint-disable @typescript-eslint/explicit-function-return-type */
export default {
  app: () => ({
    auth: () => ({
      signInAnonymously: () => undefined,
    }),
  }),
}
