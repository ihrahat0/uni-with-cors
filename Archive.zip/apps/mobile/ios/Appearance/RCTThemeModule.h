#import <React/RCTBridgeModule.h>

@interface ThemeModule : NSObject <RCTBridgeModule>
@end
