export const disableOnPress = (): void => {
  // Empty function used to work around nested touchable issues and longpress to press fallbacks.
}
