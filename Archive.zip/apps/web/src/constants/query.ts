export enum RefetchInterval {
  SHORT = 5000,
  MEDIUM = 15000,
  LONG = 60000,
}
