//
//  WidgetsCore.h
//  WidgetsCore
//
//  Created by Eric Huang on 6/22/23.
//

#import <Foundation/Foundation.h>

//! Project version number for WidgetsCore.
FOUNDATION_EXPORT double WidgetsCoreVersionNumber;

//! Project version string for WidgetsCore.
FOUNDATION_EXPORT const unsigned char WidgetsCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WidgetsCore/PublicHeader.h>


