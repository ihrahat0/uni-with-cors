import { LogBox } from 'react-native'

LogBox.ignoreAllLogs()
