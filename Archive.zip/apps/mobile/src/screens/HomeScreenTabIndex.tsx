export enum HomeScreenTabIndex {
  Tokens = 0,
  NFTs = 1,
  Activity = 2,
  Feed = 3,
}
