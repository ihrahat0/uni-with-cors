export { escapeRegExp } from './escapeRegExp'
