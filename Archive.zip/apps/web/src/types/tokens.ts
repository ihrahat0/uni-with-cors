import { Token } from '@uniswap/sdk-core'

export class UserAddedToken extends Token {}
