export const TestWallet = {
  name: 'Wallet 1',
  recoveryPhrase:
    'oak reduce strong borrow control funny library disagree radio clarify degree pistol',
}

export const TestWatchedWallet = {
  ens: 'Spenciefy',
  displayName: 'spencer',
}
