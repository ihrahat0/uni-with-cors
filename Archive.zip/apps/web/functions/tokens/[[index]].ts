// Keep rich link previews for legacy /tokens URL.
// eslint-disable-next-line import/no-unused-modules
export { onRequest } from '../explore/tokens/[[index]]'
